const http = require('http');
const fibonacci = require('./fibonacci');
const tamgiac = require('./tamgiac');
const songuyento = require('./songuyento');
const thongke = require('./thongke');
const cuuchuong = require('./cuuchuong');
const palindrome = require('./palindrome');
const PORT = 3000;

const server = http.createServer((req, res) => {
    const baseURL = `http://${req.headers.host}`;
    const parsedUrl = new URL(req.url, baseURL);

    const pathname = parsedUrl.pathname;
    const method = req.method;

    console.log(`Nhận dc request:[${method}]${req.url}`);

    res.setHeader('Content-Type', 'text/html;charset=utf-8');
    if (pathname === '/') {
        res.writeHead(200);
        res.end(`<h1>Home</h1>
        <a href="/fibonacci">Đến trang Fibonacci</a>
        <a href="/tamgiac">Đến trang Tam giác</a>
        <a href="/songuyento">Đến trang Số nguyên tố</a>
        <a href="/thongke">Đến trang Thống kê</a>
        <a href="/cuuchuong">Đến trang Cửu chương</a>
        <a href="/palindrome">Đến trang Palindrome</a>`);
    } else if (pathname === '/fibonacci') {
        fibonacci(req, res);
    } else if (pathname === '/tamgiac') {
        tamgiac(req, res);
    } else if (pathname === '/songuyento') {
        songuyento(req, res);
    } else if (pathname === '/thongke') {
        thongke(req, res);
    } else if (pathname === '/cuuchuong') {
        cuuchuong(req, res);
    } else if (pathname === '/palindrome') {
        palindrome(req, res);
    } else {
        res.writeHead(404);
        res.end(`<h1>404 - Không tìm thấy trang</h1>`);
    }
});

server.listen(PORT, () => {
    console.log(`Server đang chạy tại http://localhost:${PORT}`);
});